﻿using OCR.TesseractWrapper; //引用
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Threading;
using System.Management;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        [System.Runtime.InteropServices.DllImport("user32")]
        private static extern int mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
        const int MOUSEEVENTF_MOVE = 0x0001;      //移动鼠标 
        const int MOUSEEVENTF_LEFTDOWN = 0x0002; //模拟鼠标左键按下 
        const int MOUSEEVENTF_LEFTUP = 0x0004; //模拟鼠标左键抬起 
        const int MOUSEEVENTF_RIGHTDOWN = 0x0008; //模拟鼠标右键按下 
        const int MOUSEEVENTF_RIGHTUP = 0x0010; //模拟鼠标右键抬起 
        const int MOUSEEVENTF_MIDDLEDOWN = 0x0020; //模拟鼠标中键按下 
        const int MOUSEEVENTF_MIDDLEUP = 0x0040;// 模拟鼠标中键抬起 
        const int MOUSEEVENTF_ABSOLUTE = 0x8000; //标示是否采用绝对坐标

        [DllImport("user32.dll")]
        public static extern int SetWindowsHookEx(int idHook, HookProc hProc, IntPtr hMod, int dwThreadId);
        [DllImport("user32.dll")]
        public static extern int CallNextHookEx(int hHook, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")]
        public static extern bool UnhookWindowsHookEx(int hHook);
        [DllImport("kernel32.dll")]//获取模块句柄  
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll", EntryPoint = "keybd_event")]
        public static extern void keybd_event(byte bVk,byte bScan,int dwFlags,int dwExtraInfo);


        public struct KeyInfoStruct
        {
            public int vkCode;        //按键键码
            public int scanCode;
            public int flags;       //键盘是否按下的标志
            public int time;
            public int dwExtraInfo;
        }
        private const int WH_KEYBOARD_LL = 13;      //钩子类型 全局钩子
        private const int WM_KEYUP = 0x101;     //按键抬起
        private const int WM_KEYDOWN = 0x100;       //按键按下

        public delegate int HookProc(int nCode, IntPtr wParam, IntPtr lParam);
        bool bStopMsg = false;
        int hHook = 0;
        int FishState = 0;      //自动钓鱼线程状态
        int StoneState = 0;     //自动刷石头线程状态
        int CSState = 0;     //现代生存线程状态
        int isDisconnect = 0;
        GCHandle gc;
        Thread FishThread;  //线程
        Thread StoneThread;  //线程
        Thread CSThread;  //线程 现代生存专用掉线重连线程
        TesseractProcessor ImgProcess;
        //全局监听
        public int MethodHookProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                KeyInfoStruct inputInfo = (KeyInfoStruct)Marshal.PtrToStructure(lParam, typeof(KeyInfoStruct));
                if (wParam == (IntPtr)WM_KEYDOWN)//如果按键按下
                {
                  //  MessageBox.Show(((Keys)inputInfo.vkCode).ToString());
                    if (((Keys)inputInfo.vkCode).ToString() == "F6")   //掉线重连 todo
                    {
                        if (CSState == 0)
                        {
                            CSThread.Resume(); //恢复线程 
                            CSState = 1;
                        }
                        else
                        {
                            CSThread.Suspend(); //暂停线程
                            CSState = 0;
                        }
                    }
                    if (((Keys)inputInfo.vkCode).ToString() == "F7")   //自动钓鱼的线程开关
                    {
                        if (FishState == 0)
                        {
                            FishThread.Resume(); //恢复线程 
                            FishState = 1;
                        }
                        else
                        {
                            FishThread.Suspend(); //暂停线程
                            FishState = 0;
                        }
                            
                    }
                    if (((Keys)inputInfo.vkCode).ToString() == "F8")   //自动刷石头线程开关
                    {
                        if (StoneState == 0)
                        {
                            StoneThread.Resume(); //恢复线程 
                            StoneState = 1;
                        }
                        else
                        {
                            StoneThread.Suspend(); //暂停线程
                            StoneState = 0;
                            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0); //鼠标左键松开
                        }
                    }
                        
                }
                if (bStopMsg)
                    return 1;
            }
            return CallNextHookEx(hHook, nCode, wParam, lParam);//继续传递消息
        }

        public Form1()  //form初始化
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) //初始化完成后的加载窗体的初始化
        {
           
            if (0 == hHook)
            {
                HookProc KeyCallBack = new HookProc(MethodHookProc);   //钩子 全局监听
                hHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyCallBack,
                    GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName), 0);
                if (hHook == 0)
                {
                    MessageBox.Show("设置Hook失败");
                }
                else
                {
                    gc = GCHandle.Alloc(KeyCallBack);   //保持活动 避免 回调过程 被垃圾回收
                }
            }
            else
            {
                if (UnhookWindowsHookEx(hHook))
                {
                    hHook = 0;
                    gc.Free();
                }
                else
                {
                    MessageBox.Show("卸载失败");
                }
            }

            //初始化图像识别的系统
            ImgProcess = new TesseractProcessor();
            ImgProcess.SetPageSegMode(ePageSegMode.PSM_SINGLE_LINE);
            ImgProcess.Init(System.Environment.CurrentDirectory + "\\", "eng", (int)eOcrEngineMode.OEM_DEFAULT);
            
            //初始化处理线程
            ThreadStart threadStart = new ThreadStart(Fish);
            FishThread = new Thread(threadStart);
            FishThread.Start();
            FishThread.Suspend();

            ThreadStart threadStart2 = new ThreadStart(Stone);
            StoneThread = new Thread(threadStart2);
            StoneThread.Start();
            StoneThread.Suspend();

            ThreadStart threadStart3 = new ThreadStart(CS);
            CSThread = new Thread(threadStart3);
            CSThread.Start();
            CSThread.Suspend(); 

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;   //最小化窗口
            Bitmap bit = new Bitmap(20, 20);
            Graphics g = Graphics.FromImage(bit);
            g.CopyFromScreen(new Point(1255, 746), new Point(0, 0), bit.Size);
            bit.Save("D:\\12345.jpg");
            bit.Dispose();
            g.Dispose();
        }

       
        //整个的处理函数 自动钓鱼线程函数
        public void Fish()
        {
            //Bitmap bit = new Bitmap(130, 120);//中文的识别
            Bitmap bit = new Bitmap(390, 180);  //选择割取的图片面积
            Graphics g = Graphics.FromImage(bit);
            string last_result; //上一次的识别结果
            string result = "";
            int com_count = 0;
            while (true)
            {
                g.CopyFromScreen(new Point(1524, 780), new Point(0, 0), bit.Size); //获取屏幕部分截图
                //g.CopyFromScreen(new Point(1620, 880), new Point(0, 0), bit.Size);//中文识别参数

                //上一次的识别结果
                last_result = string.Copy(result);
                result = ImgProcess.Recognize(bit);//得到英文识别结果 当前的
                textBox1.Text = result;                     //显示识别结果
                //比较上次和当前的结果，如果一样，计数++
                if (string.Compare(result, last_result, true) == 0)
                {
                    com_count++;
                }
                else
                {
                    com_count = 0; //归零
                }
                if (com_count > 10000)  //太多次相同了
                {
                    isDisconnect = 1; //判断出来掉线了 在另一个线程处理
                }
                
                //bit.Save("D:\\12345.jpg"); //作为验证

                //判断是否上钩
                if (result.Contains("Fi") || result.Contains("Ti"))
                {
                    //keybd_event(65, 0, 0, 0);//a
                    mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0); //鼠标右键点击 收起来鱼竿
                    Thread.Sleep(10);
                    mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0); //鼠标右键点击 放下鱼竿
                    Thread.Sleep(3000); //休息3秒钟，防止重复检测
                }
   
            }



            //mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0); //鼠标点击
            //keybd_event(65, 0, 0, 0);//a
            //keybd_event((byte)Keys.F5, 0, 0, 0);//按下F11
            //keybd_event((byte)Keys.F5, 0, 0x2, 0);   //弹起F11
            //Thread.Sleep(1000);//
        }

        public void Stone()//刷石机\刷怪
        {

            while (true)
            {
                mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0); //一秒打一下刷怪
                Thread.Sleep(1000);
                /* 刷石机
                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0); //
                Thread.Sleep(1200);
                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0); //
                Thread.Sleep(3500);
                */
            }


        }


        //关闭某个线程
        public static void stopNamedProcess(string name)
        {
            foreach (Process p in System.Diagnostics.Process.GetProcessesByName(name))
            {
                
                try
                {
                    p.Kill();
                    p.WaitForExit();
                }
                catch (Exception exp)
                {
                    Console.WriteLine(exp.Message);
                    System.Diagnostics.EventLog.WriteEntry("AlchemySearch:KillProcess", exp.Message, System.Diagnostics.EventLogEntryType.Error);
                }
            }
        }
        public void CS()
        {
            while (false)
            {
                //if(isDisconnect == 1) //如果掉线了
                if (false) //判断是否断线
                {
                    //暂停钓鱼线程
                    FishThread.Suspend();
                    //关闭我的世界进程
                    stopNamedProcess("javaw");
                    //关闭多玩盒子进程
                    stopNamedProcess("MCPCBox");
                    Thread.Sleep(5000);
                    //打开多玩盒子
                    System.Diagnostics.Process.Start(@"C:\Users\84225\Desktop\MCbox.lnk");
                    Thread.Sleep(5000);
                    //打开我的世界

                    //等待好几分钟，点击到服务器中

                    //选择空岛，进入空岛，选择鱼竿


                    //放下鱼竿钓鱼

                    //开启钓鱼线程
                }
            }
            




        }

    }
}
